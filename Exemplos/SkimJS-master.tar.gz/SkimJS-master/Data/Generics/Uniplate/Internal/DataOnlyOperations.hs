{-# LANGUAGE CPP, MultiParamTypeClasses #-}

module Data.Generics.Uniplate.Internal.DataOnlyOperations where

#include "OperationsInc.hs"
